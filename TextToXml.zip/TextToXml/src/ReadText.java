import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class ReadText {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		String file = args[0];
		StringBuilder sb = new StringBuilder();
		int[] firstLineInteger = { 20, 28, 30, 36, 43 };
		int[] secondLineInteger = { 10, 14, 21, 28, 35, 39, 47, 48 };
		String constantHeader = "<HEADER ID=\"1\"";
		String[] firstLineString = { "LOADCLOSEDDATETIME=", "DELIVERYDATE=", "DEPOTCODE=", "TRAILERID=",
				"TRIPROUTEID=" };
		String[] secondLineString = { "<RECORD TPNB=", "NOOFCASES=", "OUTERCASELENGTH=", "OUTERCASEWIDTH=",
				"OUTERCASEHEIGHT=", "UNITSPERCASE=", "USEBYDATE=", "MU=" };
		sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		sb.append("\n");
		sb.append("\t");
		sb.append("<MESSAGE ID=\"PND\">");
		sb.append("\n");
		sb.append("\t\t");
		sb.append("<STORE ID=\"6997\">");
		sb.append("\n");
		sb.append("\t\t\t");
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			String line;
			int index = 0;
			while ((line = br.readLine()) != null) {
				
				if (index == 0) {
					String firstLine = line.replaceAll("\\s+", "");
					int begin = 6;
					sb.append(constantHeader);
					for (int i = 0; i < firstLineString.length; i++) {
						sb.append("\t");
						sb.append(firstLineString[i]);
						sb.append("\"" + firstLine.substring(begin, firstLineInteger[i]) + "\"");
						begin = firstLineInteger[i];
					}
					sb.append("/>");
					sb.append("\n");
					sb.append("\t\t\t\t");
					sb.append("<DETAILRECORD ID=\"2\">");
					sb.append("\n");
				} else if (line.contains("Y")) {
					index=index-1;

				}
			else if (line.charAt(0)=='2' && line.contains("N")){
					
					sb.append("\t\t\t\t\t");
					int begin = 2;
					for (int i = 0; i < secondLineString.length; i++) {
						sb.append("\t");
						sb.append(secondLineString[i]);
						sb.append("\"" + line.substring(begin, secondLineInteger[i]) + "\"");
						begin = secondLineInteger[i];
					}
					sb.append("/>");
					sb.append("\n");

				}
			else if (line.charAt(0)=='9')
			{
				sb.append("\t\t\t\t");
				sb.append("</DETAILRECORD ID=\"2\">");
				sb.append("\n");
				sb.append("\t\t\t");
				sb.append("</STORE>");
				sb.append("\n");
				sb.append("\t\t");
				sb.append("<TRAILER ID=\"9\" RECORDCOUNT="+ index + "/>");
				sb.append("\n");
				sb.append("\t");
				sb.append("</MESSAGE>");
				sb.append("\n");
				sb.append("</XML>");
			}
				index++;
			}
		}
		System.out.println(sb);
		PrintWriter print = new PrintWriter("output.txt", "UTF-8");
		print.write(sb + "");
		print.close();

	}
}
